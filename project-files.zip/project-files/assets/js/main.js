$(function () {
  console.log('Page loaded');
});
