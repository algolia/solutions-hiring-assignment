module.exports = {
  extends: 'algolia'
};
